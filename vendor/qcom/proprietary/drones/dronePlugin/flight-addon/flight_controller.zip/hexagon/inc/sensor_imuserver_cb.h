#pragma once
/*==============================================================================
 Copyright (c) 2016 Qualcomm Technologies, Inc.
 All rights reserved. Qualcomm Proprietary and Confidential.
 ==============================================================================*/
 /**
  * This file provides the interfaces to call from the mpu9x50 driver.
  * This header file should not be used other than the MPU 9x50
  **/
#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include "sensor_datatypes.h"
#include "sensor_imu_datatypes_dsponly.h"


/**
 * This function will register the IMU device with the imu server.
 * The return value of this function will provide an device handle.  Use this handle to call the 
 * other callback methods.
 * @param imu_type
 *   Specify the IMU function.
 * @param description 
 *   A char buffer to describe the IMU device.
 * @param size_in_bytes
 *    The size of the description buffer.
 * @param buffer_size
 *    The size of the Server Buffer in sample count.
 * @return 
 *   0     ---> failure
 *   other ---> success; 
 */
imu_device* sensor_imuserver_cb_register_imu_device
( 
  sensor_imu_type imu_type,
  char*           description, 
  int32_t         size_in_bytes,
  int32_t         buffer_size
);

/**
* Callback method to register the imu raw frame to body frame rotation matrix.
* The rotation matrix is a 3x3 matrix. This is a linear array with the following order:
* [(0,0),(0,1),(0,2),(1,0),(1,1),(1,2),(2,0),(2,1),(2,2)]
* @param dev_id
*   The device id for which this data is associated with.
* @param rotation_matrix_3x3
*   the rotation matrix
* @param array_size
*   The array size.  This shall always be 9.
* @return 
*   0 = success;
*  other = failure.
*/
int16_t sensor_imu_attitude_cb_register_raw_frame_to_body_rotation_matrix
( 
  imu_device* dev_id, 
  float*      rotation_matrix_3x3, 
  int16_t     array_size 
);

/**
 * This is a call back from the IMU driver to notify that the 
 * @param dev_id
*   The device id for which this data is associated with.
 * the IMU is initialized.
 * @param driver_settings
 *   This gives the driver settings use for the IMU.
 */
int16_t sensor_imuserver_cb_driver_initialized( imu_device* dev_id, sensor_mpu_driver_settings* driver_settings );

/**
 * This is called when a single IMU data is received.
* @param dev_id
*   The device id for which this data is associated with. 
 * @param data
 * 	represents the received IMU data.
 * @return 
 * 	= 0 succesful
 *  otherwise = error/failure.
 */
int16_t sensor_imuserver_cb_imu_data_received( imu_device* dev_id, sensor_imu* data );

/**
 * callback to send the IMU data based on fifo read.
* @param dev_id
*   The device id for which this data is associated with. 
 * @param data_list
 * 	an array of the imu data
 * @param size
 * 	the size of the array
 * @return 
 * 	0 = success
 * 	otherwise = error/failure
 */
int16_t sensor_imuserver_cb_imu_data_multiple( imu_device* dev_id, sensor_imu *data_list, uint16_t size );

/**
 * Callback to notify that the imu device is closed.
* @param dev_id
*   The device id for which this data is associated with. 
 * @return 
 *   0 = success
 *   otherwise = error/failure.
 **/
int16_t sensor_imuserver_cb_driver_closed( imu_device* dev_id ); 


#ifdef __cplusplus
}
#endif

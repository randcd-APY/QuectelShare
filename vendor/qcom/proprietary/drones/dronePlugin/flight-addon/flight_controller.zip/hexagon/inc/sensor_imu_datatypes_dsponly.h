#pragma once
#ifdef __cplusplus 
extern "C" {
#endif

/**
 * Handle to represent the implementation of the sensor_imu_attitude_api
 */
typedef struct imu_device imu_device;


// add adsp only data types here.
/**
 * Structure to hold the bias estimations as computed 
 * by the flight stack. 
 * *NOTE* This will not be exposed via the fast RPC API
 */
typedef struct {
  float linear_accel_bias_offset[IMU_MAX_DIMENSIONS];
  float angular_velocity_bias_offset[IMU_MAX_DIMENSIONS];
} __attribute__((packed)) sensor_imu_bias_offsets;


#ifdef __cplusplus
}
#endif
